/**
 * Liquid Glass FAB - Professional Standalone Module
 * Apple Vision Pro style water drop button with spring physics
 *
 * @version 1.0.0
 * @license MIT
 * @author vnxORACLE
 *
 * Features:
 * - Spring physics for organic motion (Hooke's law)
 * - 8-corner morphing with CSS variables
 * - Glass morphism with backdrop filters
 * - Water drop entrance animation
 * - Ripple effect on click
 * - Parallax icon movement
 * - Light caustics following cursor
 * - Full instance isolation (multiple buttons per page)
 * - Framework agnostic vanilla JS
 *
 * Usage:
 *   import { LiquidGlassFAB } from './LiquidGlassFAB.js'
 *   const fab = new LiquidGlassFAB(containerElement, {
 *     size: 80,
 *     icon: '<svg>...</svg>',
 *     ariaLabel: 'Toggle chat',
 *     onToggle: (isOpen) => console.log('Toggled:', isOpen)
 *   })
 *   fab.setState(true)
 *   fab.destroy()
 */

// Spring physics simulation for organic motion
class SpringValue {
    constructor(initial, stiffness = 0.1, damping = 0.8) {
        this.current = initial
        this.target = initial
        this.velocity = 0
        this.stiffness = stiffness
        this.damping = damping
    }

    update() {
        // Hooke's law: F = -kx
        this.velocity += (this.target - this.current) * this.stiffness
        this.velocity *= this.damping
        this.current += this.velocity

        // Settle threshold to stop micro-oscillations
        if (Math.abs(this.velocity) < 0.001 && Math.abs(this.target - this.current) < 0.001) {
            this.current = this.target
            this.velocity = 0
        }
    }

    set(newTarget) {
        this.target = newTarget
    }
}

export class LiquidGlassFAB {
    constructor(container, options = {}) {
        // Validation
        if (!container || !(container instanceof HTMLElement)) {
            throw new Error('LiquidGlassFAB: First argument must be a valid HTMLElement')
        }

        // Configuration
        this.container = container
        this.options = {
            size: options.size || 80,
            icon: options.icon || this.getDefaultIcon(),
            ariaLabel: options.ariaLabel || 'Toggle',
            onToggle: options.onToggle || null,
            playEntranceAnimation: options.playEntranceAnimation !== false
        }

        // State
        this.isOpen = false
        this.isDestroyed = false
        this.isHovering = false
        this.animationFrame = null

        // Initialize
        this.createElements()
        this.initPhysics()
        this.initEventListeners()
        this.startAnimationLoop()

        if (this.options.playEntranceAnimation) {
            this.playEntranceAnimation()
        }
    }

    getDefaultIcon() {
        return `
            <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
        `
    }

    createElements() {
        // Wrapper for positioning
        this.wrapper = document.createElement('div')
        this.wrapper.className = 'liquid-glass-fab__wrapper'

        // Main FAB button
        this.fab = document.createElement('button')
        this.fab.className = 'liquid-glass-fab'
        this.fab.setAttribute('aria-label', this.options.ariaLabel)
        this.fab.setAttribute('type', 'button')

        // Set size via inline styles for dynamic sizing
        this.fab.style.width = `${this.options.size}px`
        this.fab.style.height = `${this.options.size}px`

        // Icon container
        const iconContainer = document.createElement('div')
        iconContainer.className = 'liquid-glass-fab__icon'
        iconContainer.innerHTML = this.options.icon

        this.fab.appendChild(iconContainer)
        this.wrapper.appendChild(this.fab)
        this.container.appendChild(this.wrapper)
    }

    initPhysics() {
        // Light caustics (cursor-following effect)
        this.lightX = new SpringValue(35, 0.08, 0.82)
        this.lightY = new SpringValue(35, 0.08, 0.82)

        // Scale for hover/click effects
        this.scale = new SpringValue(1.0, 0.15, 0.75)

        // Shine offset (surface reflection)
        this.shineX = new SpringValue(0, 0.06, 0.85)
        this.shineY = new SpringValue(0, 0.06, 0.85)

        // 8-corner morphing (border-radius manipulation)
        // Each corner has horizontal and vertical radius components
        this.morphTL = new SpringValue(50, 0.14, 0.78)   // Top-left horizontal
        this.morphTR = new SpringValue(50, 0.14, 0.78)   // Top-right horizontal
        this.morphBR = new SpringValue(50, 0.14, 0.78)   // Bottom-right horizontal
        this.morphBL = new SpringValue(50, 0.14, 0.78)   // Bottom-left horizontal
        this.morphTLV = new SpringValue(50, 0.14, 0.78)  // Top-left vertical
        this.morphTRV = new SpringValue(50, 0.14, 0.78)  // Top-right vertical
        this.morphBRV = new SpringValue(50, 0.14, 0.78)  // Bottom-right vertical
        this.morphBLV = new SpringValue(50, 0.14, 0.78)  // Bottom-left vertical

        // Position offset (not used currently, reserved for future)
        this.translateX = new SpringValue(0, 0.08, 0.84)
        this.translateY = new SpringValue(0, 0.08, 0.84)

        // Icon parallax (slight movement inside button)
        this.parallaxX = new SpringValue(0, 0.10, 0.88)
        this.parallaxY = new SpringValue(0, 0.10, 0.88)
    }

    initEventListeners() {
        // Store bound functions for proper cleanup
        this.onEnterBound = this.onEnter.bind(this)
        this.onLeaveBound = this.onLeave.bind(this)
        this.onMoveBound = this.onMove.bind(this)
        this.onClickBound = this.onClick.bind(this)

        this.fab.addEventListener('pointerenter', this.onEnterBound)
        this.fab.addEventListener('pointerleave', this.onLeaveBound)
        this.fab.addEventListener('pointermove', this.onMoveBound)
        this.fab.addEventListener('click', this.onClickBound)
    }

    onEnter() {
        this.isHovering = true
        this.scale.set(1.1)
    }

    onLeave() {
        this.isHovering = false

        // Reset light to center
        this.lightX.set(35)
        this.lightY.set(35)

        // Reset scale
        this.scale.set(1.0)

        // Reset shine
        this.shineX.set(0)
        this.shineY.set(0)

        // Reset morphing to perfect circle
        const morphTargets = [
            this.morphTL, this.morphTR, this.morphBR, this.morphBL,
            this.morphTLV, this.morphTRV, this.morphBRV, this.morphBLV
        ]
        morphTargets.forEach(m => m.set(50))

        // Reset position
        this.translateX.set(0)
        this.translateY.set(0)

        // Reset icon parallax
        this.parallaxX.set(0)
        this.parallaxY.set(0)
    }

    onMove(e) {
        if (!this.isHovering) return

        const rect = this.fab.getBoundingClientRect()
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top

        // Normalized coordinates (0-100 range)
        const normX = (x / rect.width) * 100
        const normY = (y / rect.height) * 100

        // Update light position (caustics follow cursor)
        this.lightX.set(normX)
        this.lightY.set(normY)

        // Shine effect (surface reflection offset)
        const shineOffsetX = (normX - 50) * 0.15
        const shineOffsetY = (normY - 50) * 0.15
        this.shineX.set(shineOffsetX)
        this.shineY.set(shineOffsetY)

        // Icon parallax (subtle depth effect)
        const parallaxX = (normX - 50) * 0.12
        const parallaxY = (normY - 50) * 0.12
        this.parallaxX.set(parallaxX)
        this.parallaxY.set(parallaxY)

        // 8-corner morphing based on cursor quadrant
        const centerX = rect.width / 2
        const centerY = rect.height / 2
        const distance = Math.hypot(x - centerX, y - centerY) / centerX
        const deformAmount = Math.min(distance * 35, 45)

        // Reset all corners first
        const allMorphs = [
            this.morphTL, this.morphTR, this.morphBR, this.morphBL,
            this.morphTLV, this.morphTRV, this.morphBRV, this.morphBLV
        ]

        // Determine quadrant and apply asymmetric morphing
        if (normX < 50 && normY < 50) {
            // Top-left quadrant: push TL corner out, pull BR corner in
            this.morphTL.set(50 + deformAmount * 0.4)
            this.morphTLV.set(50 + deformAmount * 0.3)
            this.morphBR.set(50 - deformAmount * 0.3)
            this.morphBRV.set(50 - deformAmount * 0.2)
            this.morphTR.set(50 + deformAmount * 0.2)
            this.morphBL.set(50 + deformAmount * 0.2)
            this.morphTRV.set(50)
            this.morphBLV.set(50)
        } else if (normX >= 50 && normY < 50) {
            // Top-right quadrant
            this.morphTR.set(50 + deformAmount * 0.4)
            this.morphTRV.set(50 + deformAmount * 0.3)
            this.morphBL.set(50 - deformAmount * 0.3)
            this.morphBLV.set(50 - deformAmount * 0.2)
            this.morphTL.set(50 + deformAmount * 0.2)
            this.morphBR.set(50 + deformAmount * 0.2)
            this.morphTLV.set(50)
            this.morphBRV.set(50)
        } else if (normX >= 50 && normY >= 50) {
            // Bottom-right quadrant
            this.morphBR.set(50 + deformAmount * 0.4)
            this.morphBRV.set(50 + deformAmount * 0.3)
            this.morphTL.set(50 - deformAmount * 0.3)
            this.morphTLV.set(50 - deformAmount * 0.2)
            this.morphBL.set(50 + deformAmount * 0.2)
            this.morphTR.set(50 + deformAmount * 0.2)
            this.morphBLV.set(50)
            this.morphTRV.set(50)
        } else {
            // Bottom-left quadrant
            this.morphBL.set(50 + deformAmount * 0.4)
            this.morphBLV.set(50 + deformAmount * 0.3)
            this.morphTR.set(50 - deformAmount * 0.3)
            this.morphTRV.set(50 - deformAmount * 0.2)
            this.morphTL.set(50 + deformAmount * 0.2)
            this.morphBR.set(50 + deformAmount * 0.2)
            this.morphTLV.set(50)
            this.morphBRV.set(50)
        }
    }

    onClick(e) {
        // Squash effect (press down)
        this.scale.set(0.96)
        setTimeout(() => {
            this.scale.set(this.isHovering ? 1.1 : 1.0)
        }, 150)

        // Ripple effect
        this.createRipple(e)

        // Toggle state
        this.isOpen = !this.isOpen

        // Callback
        if (this.options.onToggle) {
            this.options.onToggle(this.isOpen)
        }
    }

    createRipple(e) {
        const ripple = document.createElement('div')
        ripple.className = 'liquid-glass-fab__ripple'

        const rect = this.fab.getBoundingClientRect()
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top

        ripple.style.left = `${x}px`
        ripple.style.top = `${y}px`

        this.fab.appendChild(ripple)

        // Auto-remove after animation
        setTimeout(() => {
            if (ripple.parentNode) {
                ripple.remove()
            }
        }, 800)
    }

    startAnimationLoop() {
        const animate = () => {
            if (this.isDestroyed) return

            // Update all spring physics
            this.lightX.update()
            this.lightY.update()
            this.scale.update()
            this.shineX.update()
            this.shineY.update()
            this.morphTL.update()
            this.morphTR.update()
            this.morphBR.update()
            this.morphBL.update()
            this.morphTLV.update()
            this.morphTRV.update()
            this.morphBRV.update()
            this.morphBLV.update()
            this.translateX.update()
            this.translateY.update()
            this.parallaxX.update()
            this.parallaxY.update()

            // Apply physics values to CSS custom properties
            this.fab.style.setProperty('--light-x', `${this.lightX.current}%`)
            this.fab.style.setProperty('--light-y', `${this.lightY.current}%`)
            this.fab.style.setProperty('--scale', this.scale.current)
            this.fab.style.setProperty('--shine-x', `${this.shineX.current}px`)
            this.fab.style.setProperty('--shine-y', `${this.shineY.current}px`)
            this.fab.style.setProperty('--radius-tl', `${this.morphTL.current}%`)
            this.fab.style.setProperty('--radius-tr', `${this.morphTR.current}%`)
            this.fab.style.setProperty('--radius-br', `${this.morphBR.current}%`)
            this.fab.style.setProperty('--radius-bl', `${this.morphBL.current}%`)
            this.fab.style.setProperty('--radius-tl-v', `${this.morphTLV.current}%`)
            this.fab.style.setProperty('--radius-tr-v', `${this.morphTRV.current}%`)
            this.fab.style.setProperty('--radius-br-v', `${this.morphBRV.current}%`)
            this.fab.style.setProperty('--radius-bl-v', `${this.morphBLV.current}%`)
            this.fab.style.setProperty('--translateX', `${this.translateX.current}px`)
            this.fab.style.setProperty('--translateY', `${this.translateY.current}px`)
            this.fab.style.setProperty('--parallax-x', `${this.parallaxX.current}px`)
            this.fab.style.setProperty('--parallax-y', `${this.parallaxY.current}px`)

            // Schedule next frame
            this.animationFrame = requestAnimationFrame(animate)
        }

        animate()
    }

    playEntranceAnimation() {
        this.fab.classList.add('liquid-glass-fab--drop-entrance')

        setTimeout(() => {
            if (!this.isDestroyed) {
                this.fab.classList.remove('liquid-glass-fab--drop-entrance')
            }
        }, 1600)
    }

    /**
     * Update button state
     * @param {boolean} isOpen - New state
     */
    setState(isOpen) {
        this.isOpen = isOpen
        // Visual state changes can be added here if needed
        // e.g., this.fab.classList.toggle('liquid-glass-fab--open', isOpen)
    }

    /**
     * Get current state
     * @returns {boolean}
     */
    getState() {
        return this.isOpen
    }

    /**
     * Clean up and remove the button
     * Stops animation loop, removes event listeners, and removes DOM elements
     */
    destroy() {
        // Mark as destroyed to stop animation loop
        this.isDestroyed = true

        // Cancel animation frame
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame)
            this.animationFrame = null
        }

        // Remove event listeners
        if (this.fab) {
            this.fab.removeEventListener('pointerenter', this.onEnterBound)
            this.fab.removeEventListener('pointerleave', this.onLeaveBound)
            this.fab.removeEventListener('pointermove', this.onMoveBound)
            this.fab.removeEventListener('click', this.onClickBound)
        }

        // Remove DOM elements
        if (this.wrapper && this.wrapper.parentNode) {
            this.wrapper.remove()
        }

        // Clear references for garbage collection
        this.fab = null
        this.wrapper = null
        this.container = null
        this.options = null
    }
}
